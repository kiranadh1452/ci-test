<?php



// No direct access to this file
defined('_JEXEC') or die;

/**
 * Dropbox component helper.
 */
abstract class DropboxHelper
{
	/**
	 * Configure the Linkbar.
	 */
	public static function addSubmenu($submenu) 
	{
		JHtmlSidebar::addEntry(JText::_('Boxes'), 'index.php?option=com_dropbox', $submenu == 'boxes');
		JHtmlSidebar::addEntry(JText::_('Logs'), 'index.php?option=com_dropbox&view=logs', $submenu == 'logs');
	}
	/**
	 * Get the actions
	 */
	public static function getActions($messageId = 0)
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($messageId)) {
			$assetName = 'com_dropbox';
		}
		else {
			$assetName = 'com_dropbox.message.'.(int) $messageId;
		}

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}
}
