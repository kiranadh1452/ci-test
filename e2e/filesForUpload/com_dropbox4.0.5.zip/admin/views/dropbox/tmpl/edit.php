<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_redirect
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Include the HTML helpers.
JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
JHtml::_('formbehavior.chosen', 'select');
$params = $this->form->getFieldsets('params');

?>
<script type="text/javascript">
	jQuery( document ).ready(function() {
		hide_show_connect_button();
		
		jQuery( "#jform_dropbox_secret" ).on("change keypress", function(event){
			hide_show_connect_button();
		});
	});
	
	Joomla.submitbutton = function(task)
	{
		if (task == 'link.cancel' || document.formvalidator.isValid(document.id('link-form')))
		{
			Joomla.submitform(task, document.getElementById('link-form'));
		}
		if (task == "dropbox.connect" )
		{
			if (jQuery("#jform_dropbox_secret").val() != '')
			{
				return false;
			}
		}
		if (task === "dropbox.connect" || task === "dropbox.preview" )
		{
			window.open('<?php echo JRoute::_('../index.php?option=com_dropbox&id='.(int) $this->item->id); ?>','_blank');
		}		
	};	

	
</script>

<form action="<?php echo JRoute::_('index.php?option=com_dropbox&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="link-form" class="form-validate form-horizontal">
	<fieldset>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_DROPBOX_DROPBOX_DETAILS') : JText::sprintf('COM_DROPBOX_DROPBOX_DETAILS', $this->item->id); ?></a></li>
			<?php foreach ($params as $name => $fieldset): ?>
			<li><a href="#<?php echo $name;?>" data-toggle="tab"><?php echo JText::_($fieldset->label);?></a></li>
			<?php endforeach; ?>
		</ul>
		<div class="tab-content">
			<div class="tab-pane active" id="details">
				<?php foreach($this->form->getFieldset('details') as $field): ?>
					<div class="control-group">
						<div class="control-label"><?php echo $field->label; ?></div>
						<div class="controls"><?php echo $field->input; ?></div>
					</div>		
				<?php endforeach; ?>
			</div>
			<?php foreach ($params as $name => $fieldset): ?>
			
			<div class="tab-pane" id="<?php echo $name;?>">
				<?php foreach($this->form->getFieldset($name) as $field): ?>
					<div class="control-group">
						<div class="control-label"><?php echo $field->label; ?></div>
						<div class="controls">
						<?php
						//don't know why I need to to this, but 3.7 does react different to 3.5
						//see more details: https://github.com/joomla/joomla-cms/issues/16696
						if( version_compare( JVERSION, '3.7', 'ge')) {
							if (isset($this->item->params["data"][$field->fieldname])) {
								$field->setValue($this->item->params["data"][$field->fieldname]);
							}
						}
						echo $field->input; 
						?></div>
						
					</div>
				<?php endforeach; ?>
				
			</div>
			<?php endforeach; ?>
			
			
			
		</div>
		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
	</fieldset>
</form>
