<?php
/**
 * @package    Joomla.Dropbox
 * @subpackage Components
 * @link http://www.individual-it.net
 * @license    GNU/GPL
*/

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// import Joomla table library
jimport('joomla.database.table');

/**
 * Dropbox Table class
 *
 * @package    Joomla.Dropbox
 * @subpackage Components
 */
class DropboxTableDropbox extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var string
	 */
	var $folder = null;

	/**
	 * @var string
	 */
	var $box_type = null;
	
	/**
	 * @var string
	 */
	var $username = null;
	
	/**
	 * @var string
	 */
	var $password = null;
	
	/**
	 * Access Level
	 *
	 * @var int
	 */
	var $access = null;	
	
	/**
	 * @var string
	 */
	var $dropbox_secret = null;
	
	/**
	 * @var string
	 */
	var $dropbox_token = null;
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function __construct(&$db) 
	{
		parent::__construct('#__dropbox', 'id', $db);
	}
	
	
	function bind($array, $ignore = '')
	{
	        if (key_exists( 'params', $array ) && is_array( $array['params'] ))
	        {
	                $registry = new JRegistry();
	                $registry->loadArray($array['params']);
	                $array['params'] = $registry->toString();
	        }
	        return parent::bind($array, $ignore);
	}
	


        /**
         * Overloaded load function
         *
         * @param       int $pk primary key
         * @param       boolean $reset reset data
         * @return      boolean
         * @see JTable:load
         */
        public function load($pk = null, $reset = true) 
        {
                if (parent::load($pk, $reset)) 
                {
                        // Convert the params field to a registry.
                        $params = new JRegistry;
                        $params->loadString($this->params);
                        $this->params = $params;
                        return true;
                }
                else
                {
                        return false;
                }
        }	
	
		
	
	
}