<?php
/**
 * @package    Joomla.Dropbox
 * @subpackage Components
 * @link http://www.individual-it.net
 * @license    GNU/GPL
*/
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.controller');
 

class DropboxController extends JControllerLegacy
{
	/**
	 * display task
	 *
	 * @return void
	 */
	function display($cachable = false, $urlparams = Array()) 
	{
		// set default view if not set
		JRequest::setVar('view', JRequest::getCmd('view', 'Dropboxes'));

		// call parent behavior
		parent::display($cachable);

		// Set the submenu
//		DropboxHelper::addSubmenu('messages');
	}
}

?>