<?php
/**
 * @package    Joomla.Dropbox
 * @subpackage Components
 * @link http://www.individual-it.net
 * @license    GNU/GPL
 */
defined('_JEXEC') or die ('Restricted access');


class com_dropboxInstallerScript
{
	/**
	 * method to install the component
	 *
	 * @return void
	 */
	function install($parent)
	{
		//load libraries
		$db = & JFactory::getDBO();

		$table_fields=$db->getTableColumns('#__dropbox');

		
		//this updates need to run at any update
		//they do not harm if they run multiple times
		//in future files in /sql/updates should be used
		if (!isset($table_fields['box_type']))
		{
			$query='ALTER TABLE `#__dropbox`
					ADD `box_type` VARCHAR(15) NOT NULL,
					ADD `username` VARCHAR(255) NOT NULL,
					ADD `password` VARCHAR(255) NOT NULL';
			$db->setQuery( $query );
			$db->query();			
		}

		$query='UPDATE `#__dropbox` SET `box_type` = "dropbox" WHERE box_type=""';
		$db->setQuery( $query );
		$db->query();
		$query='ALTER TABLE `#__dropbox` CHANGE `dropbox_token` `dropbox_token` VARCHAR(255)';
		$db->setQuery( $query );
		$db->query();
		
		// $parent is the class calling this method
		$parent->getParent()->setRedirectURL('index.php?option=com_dropbox');
	}


	/**
	 * method to run after an install/update/uninstall method
	 *
	 * @return void
	 */
	function postflight($type, $parent)
	{
		// $parent is the class calling this method
		// $type is the type of change (install, update or discover_install)
		echo '<p>' . JText::_('COM_DROPBOX_POSTFLIGHT_' . $type . '_TEXT') . '</p>';
	}
}



