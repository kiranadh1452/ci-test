<?php
class DropboxHelper {
	
	/**
	 * helper function to use from makeFilenameSafe and makeFoldernameSafe because both are so simmilar
	 * @param string $string folder or file name
	 * @param string $type file|folder|search
	 */
 	protected static function makeFileFoldernameSafe($string, $type="file") {
 		if ($type !== 'file' &&
 			$type !== 'folder' &&
 			$type !== 'search') {
 				throw new InvalidArgumentException("invalid type");
 			}
		//replace double byte whitespaces to single byte
		$str = preg_replace('/\xE3\x80\x80/', ' ', $string);
		
		//replace any multiple whitespace with a single white space
		$str = preg_replace('/\s+/', ' ', $str);
		
		if ($type !== 'search') {
			// remove any '-' from the string as they will be used as concatenator.
			$str = str_replace('-', ' ', $str);
		}
		
		//delete anything that looks like HTML or PHP
		$str=strip_tags($str);
		
		//replace forbidden characters by whitespaces
		if ($type === "folder") {
			$str = preg_replace( '#[:\#\*"@+=;!&%<>\]\'\\\\|\[]#',"-", $str );
		} else {
			$str = preg_replace( '#[:\#\*"@+=;!&%<>\]\/\'\\\\|\[]#',"-", $str );
		}
		
		//delete all '?'
		$str = str_replace('?', '', $str);
		
		//trim white spaces at beginning and end of alias
		$str = trim( $str );
		
		//replace all dots between slashes if nothing else it there with spaces
		$str = preg_replace('/\/\.+\//', "/\x20/", $str);

		//replace dot in ./ with space
		$str = preg_replace('/^\.+\//', "\x20/", $str);
		
		//replace all dots at ends with spaces
		$str = preg_replace('/\/\.+$/', "/\x20", $str);
		
		//replace any duplicate dots with spaces
		$str = preg_replace('/(\.)\1+/', "\x20", $str);
		
		// remove any duplicate slashes
		$str = preg_replace('/(\/)\1+/', "/", $str);
		
		//if only a dot is left over replace it with a space
		$str = preg_replace('/^\.$/', "\x20", $str);
		
		if ($type === "search") {
			//only single whitespaces are allowed
			$str =preg_replace('#\x20+#',' ', $str);
			$str = trim($str);
		} else {
			// remove any duplicate whitespace and replace whitespaces by hyphens
			$str =preg_replace('#\x20+#','-', $str);
		}
		
		return $str;
	}
	
	/**
	 * alternative for JFile::makeSafe that supports non ASCII filenames
	 * taken from http://forum.joomla.org/viewtopic.php?p=2075458
	 * @param string $filename
	 * @return string
	 */

	static function makeFilenameSafe($filename)
	{
		return DropboxHelper::makeFileFoldernameSafe($filename);
	}
	
	/**
	 * alternative for JFolder::makeSafe that supports non ASCII filenames
	 * taken from http://forum.joomla.org/viewtopic.php?p=2075458
	 * @param string $foldername
	 * @return string
	 */
	
	static function makeFoldernameSafe($foldername)
	{
		return DropboxHelper::makeFileFoldernameSafe($foldername,"folder");
	}
	
	/**
	 * makes the search query safe
	 * @param string $query
	 * @return mixed
	 */
	static function makeSearchSafe($query)
	{
		return DropboxHelper::makeFileFoldernameSafe($query,"search");
	}
	/**
	 * returns "cleanPath" path without the root of the dropbox connection and the file name
	 * @param string $root (unencoded)
	 * @param string $path from dropboxAPI
	 * @param string $type file|folder
	 * @return string
	 * @throws InvalidArgumentException
	 * @throws Exception
	 */
	static function makeCleanPath ($root, $path, $type) {
		if ($type !== 'file' && $type !== 'folder') {
			throw new InvalidArgumentException(
				"type can only be 'file' or 'folder'"
			);
		}

		if (substr($path, 0, 1) !== '/') {
			throw new InvalidArgumentException(
				"invalid path (no leading /)"
			);
		}

		if (preg_match("/\/{2,}/", $path) > 0) {
			throw new InvalidArgumentException(
				"invalid path (multiple /)"
			);
		}
		
		//we need to make root always start with a "/"
		if (substr($root, 0, 1) !== '/') {
			$root= "/" . $root;
		}
		//get rid of multiple /
		$root = preg_replace("/\/+/", "/", $root);
		
		$pos = strpos($path, $root);
		if ($pos !== 0) {
			throw new Exception("cannot find root in path");
		}
		// get rid of the chroot part of the path
		$cleanPath = substr_replace($path, "", $pos, strlen($root));
		
		// only get the path, not the file name
		if ($type === 'file') {
			$cleanPath = dirname($cleanPath);
		}
		
		if ($cleanPath === ".") {
			$cleanPath = "";
		}
		
		if (substr($cleanPath, 0, 1) !== '/' && $cleanPath !== "") {
			$cleanPath = "/" . $cleanPath;
		}
		
		if (substr($cleanPath, - 1) === '/' && $cleanPath !== "") {
			$cleanPath = substr($cleanPath, 0, (strlen($cleanPath) - 1));
		}

		return $cleanPath;
	}
	
	function humanFileSize($size, $unit = "")
	{
		if ((! $unit && $size >= 1 << 30) || $unit == "GB")
			return number_format($size / (1 << 30), 2) . "GB";
			if ((! $unit && $size >= 1 << 20) || $unit == "MB")
				return number_format($size / (1 << 20), 2) . "MB";
				if ((! $unit && $size >= 1 << 10) || $unit == "KB")
					return number_format($size / (1 << 10), 2) . "KB";
					return number_format($size) . " bytes";
	}
}