//var jQuery = jQuery.noConflict();

var mouse_x;
var mouse_y;


jQuery(document).bind('mousemove',function(e){ 
    mouse_x= e.pageX - jQuery(document).scrollLeft();
    mouse_y= e.pageY - jQuery(document).scrollTop() ;
    
});


var dropbox_list_aAsc = [];
function com_dropbox_sort_table(wrapper_id,name,direction) {

	if (typeof direction != "undefined") {
		dropbox_list_aAsc[name] = direction;
	} else {
		dropbox_list_aAsc[name] = dropbox_list_aAsc[name]=='asc'?'desc':'asc';
	}
	
	jQuery('div#dropbox_wrapper_'+wrapper_id).find('div.sorting_icon_asc').hide();
	jQuery('div#dropbox_wrapper_'+wrapper_id).find('div.sorting_icon_desc').hide();
	jQuery('div#dropbox_wrapper_'+wrapper_id).find('div.file_listing_header_cell.'+name).find('div.sorting_icon_'+dropbox_list_aAsc[name]).show();
	jQuery('div#dropbox_wrapper_'+wrapper_id).find('div.db_file_icon').tsort('div.'+name,{order:dropbox_list_aAsc[name]});
}


function search_dropbox_file(source_element,dropbox_search_url) {
	var value = source_element.val();
	var noWhitespaceValue = value.replace(/\s+/g, '%20');
	if (noWhitespaceValue.length >=0) {

		jQuery("#dropbox_loading_indicator").show();


		jQuery("#dropbox_loading_indicator").css('left', mouse_x-15 +'px');
		jQuery("#dropbox_loading_indicator").css('top', mouse_y-15 +'px');

		dropbox_search_url=addQueryString(dropbox_search_url,"search="+noWhitespaceValue);
		jQuery.get(dropbox_search_url, function(data) {

			jQuery("#dropbox_loading_indicator").hide();
			source_element.parent().html(data);
		});

	}
}


function change_dropbox_dir(dest_url,source_element)
{
	
	
		jQuery("#dropbox_loading_indicator").show();
		
		
		jQuery("#dropbox_loading_indicator").css('left', mouse_x-15 +'px');
		jQuery("#dropbox_loading_indicator").css('top', mouse_y-15 +'px');
		
		jQuery(document).ready(function() {
			var jqxhr = jQuery.get(dest_url, function(data) {
				if (typeof(enl_buttonurl)=='object' && typeof (enl_buttonurl[0]) == "string" && enl_buttonurl[0]) {
					enl_buttonurl[0] = 'site:'+dest_url+'&task=download&file=';
				} 
				source_element.parent().parent().parent().parent().html(data);
			});
			jqxhr.fail(function(data) {
					alert(data.statusText);
				});
			jqxhr.always(function(data) {
				jQuery("#dropbox_loading_indicator").hide();
			});
		}); 	


}


function hide_show_fields_for_different_box_types()
{
}

function hide_show_connect_button () {
	if (jQuery("#jform_dropbox_secret").val() == '') {
		jQuery( "#toolbar-arrow-right-4" ).show();
		jQuery( "#toolbar-out-2" ).hide();
	} else {
		jQuery( "#toolbar-arrow-right-4" ).hide();
		jQuery( "#toolbar-out-2" ).show();
	}
}

function addQueryString (url, queryString) {
	if (queryString) {
		var isQuestionMarkPresent = url && url.indexOf('?') !== -1,
		separator = isQuestionMarkPresent ? '&' : '?';
		url += separator + queryString;
	}

	return url;
};

