<?php
/**
 * @package    Joomla.Dropbox
 * @subpackage Components
 * @link http://www.individual-it.net
 * @license    GNU/GPL
*/

// no direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 

 
class DropboxViewDropbox extends JViewLegacy
{
	protected $data;
    function display($tpl = null)
    {
		echo $this->data;
    }
    
    function setData($data)
    {
    	$this->data=$data;
    }
}
